﻿namespace Hotel_booking.Models
{
    public class Gost
    {
    }
}