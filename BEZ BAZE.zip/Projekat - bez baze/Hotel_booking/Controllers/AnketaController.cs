﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;

namespace Hotel_booking.Controllers
{
    public class AnketaController : Controller
    {
        // MVC invokes controller classes (and the action methods within them) depending on the incoming URL.
        // The default URL routing logic used by MVC uses a format like this to determine what code to invoke
        // [Controller]/[ActionName]/[Parameters]



        // GET: /HelloWorld/

        public IActionResult Index()
        {
            return View();
        }

        // 
        // GET: /HelloWorld/Welcome/ 

        public string Welcome(string name, int ID = 1)
        {
            return HtmlEncoder.Default.Encode($"Hello {name}, NumTimes is: {ID}");
        }
    }
}