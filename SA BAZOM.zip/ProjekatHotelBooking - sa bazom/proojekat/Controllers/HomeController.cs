﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using proojekat.Models;

namespace proojekat.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Online pregled hotela i rezervacija sobe.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Informacije o autorima";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Reservation()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
